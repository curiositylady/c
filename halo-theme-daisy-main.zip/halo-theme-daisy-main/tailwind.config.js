/** @type {import('tailwindcss').Config} */
module.exports = {
    darkMode: 'class',
    content: [
        '*.ftl',
        './module/*.ftl'
    ],
    theme: {
        extend: {
        },
    },
    plugins: [],
}
